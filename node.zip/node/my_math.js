

function add(x, y) {
    return x + y;
}
function subtract(x, y) {
    return x - y;
}
function multiply(x, y) {
    return x * y;
}
function divide(x, y) {
    return x / y;
}
let pi = 3.14;// constant set to 3.14

module.exports = { add, subtract , multiply, divide, pi };
