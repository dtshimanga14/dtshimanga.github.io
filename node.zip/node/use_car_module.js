

const my_car = require("./my_car");

my_car.break();
my_car.drive();
my_car.turn();