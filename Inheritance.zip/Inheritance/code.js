

// 1. Working with prototype

let animal = {
    jumps: null
  };
  let rabbit = {
    __proto__: animal,
    jumps: true
  };
  
  alert( rabbit.jumps ); // ? (1)
  
  delete rabbit.jumps;
  
  alert( rabbit.jumps ); // ? (2)
  
  delete animal.jumps;
  
  alert( rabbit.jumps ); // ? (3)

// true, taken from rabbit.
// null, taken from animal.
// undefined, there’s no such property any more.

// // 2. Searching algorithm
//Use __proto__ to assign prototypes in a way that any property lookup will follow 
// the path: pockets → bed → table → head. For instance, pockets.pen should be 3 (found in table), 
// and bed.glasses should be 1 (found in head).
// Answer the question: is it faster to get glasses as pockets.glasses or head.glasses? Benchmark if needed.


let head = {
    glasses: 1
  };
  
  let table = {
    pen: 3
  };
  
  let bed = {
    sheet: 1,
    pillow: 2
  };
  
  let pockets = {
    money: 2000
  };

  pockets.__proto__ = bed;
  bed.__proto__ = table;
  table.__proto__ = head;

  console.log(pockets.pen); 

//  3. Write does it write ?
//We have rabbit inheriting from animal.

// If we call rabbit.eat(), which object receives the full property: animal or rabbit?

let animal2 = {
    eat() {
        this.full = true;
    }
};
let rabbit2 = {
    __proto__ : animal
};
rabbit2.eat();
// since this always points to the current object in this case,it will be rabbit.
console.log(rabbit2);

// 4. Why are both hamsters full?
// importance: 5
// We have two hamsters: speedy and lazy inheriting from the general hamster object.

// When we feed one of them, the other one is also full. Why? How can we fix it?


  let hamster = {
    stomach: [],
    eat(food) {
      this.stomach.push(food);
    }
  };
  
  let speedy = {
    __proto__: hamster
  };
  
  let lazy = {
    __proto__: hamster
  };
  
//   // This one found the food
  speedy.eat("apple");
  console.log( speedy.stomach ); // apple
  
  // This one also has it, why? fix please.
  console.log( lazy.stomach ); // apple


//   Let’s look carefully at what’s going on in the call speedy.eat("apple").

// The method speedy.eat is found in the prototype (=hamster), then executed with this=speedy (the object before the dot).

// Then this.stomach.push() needs to find stomach property and call push on it. It looks for stomach in this (=speedy), but nothing found.

// Then it follows the prototype chain and finds stomach in hamster.

// Then it calls push on it, adding the food into the stomach of the prototype.

// So all hamsters share a single stomach!

// Both for lazy.stomach.push(...) and speedy.stomach.push(), the property stomach is found in the prototype (as it’s not in the object itself), then the new data is pushed into it.

// Please note that such thing doesn’t happen in case of a simple assignment this.stomach=:

let hamster2 = {
    stomach: [],
  
    eat(food) {
      // assign to this.stomach instead of this.stomach.push
      this.stomach = [food];
    }
  };
  
  let speedy2 = {
     __proto__: hamster2
  };
  
  let lazy2 = {
    __proto__: hamster2
  };
  
  // Speedy one found the food
  speedy2.eat("apple");
  alert( speedy2.stomach ); // apple
  
  // Lazy one's stomach is empty
  alert( lazy2.stomach ); // <nothing>



// Changing "prototype"
// importance: 5
// In the code below we create new Rabbit, and then try to modify its prototype.

// In the start, we have this code:

function Rabbit() { }
Rabbit.prototype = {
    eats : true
};

let rabbit3 = new Rabbit();
// 1. Rabbit.prototype = {};
console.log(rabbit3.eats);  
// // still print true because this new assignment is for new object. 
// // rabbit was already instanciate before this assignment

Rabbit.prototype.eats = false;
console.log(rabbit3);  
rabbit3.prototype = {
    eats : true
};
console.log(rabbit3);  
console.log(Rabbit.prototype.eats);  



// Add method "f.defer(ms)" to functions
// importance: 5
// Add to the prototype of all functions the method defer(ms), that runs the function after ms milliseconds.

// After you do it, such code should work:

function f() {
    alert("Hello!");
}

Function.prototype.defer = function(ms) {
    setTimeout(this, ms);
};

function f() {
    alert("Hello!");
}
  
  f.defer(1000); // shows "Hello!" after 1 sec
  
  f.defer(1000); // shows "Hello!" after 1 second

//   Add the decorating "defer()" to functions
// importance: 4
// Add to the prototype of all functions the method defer(ms), that returns a wrapper, delaying the call by ms milliseconds.

// Here’s an example of how it should work:

function f(a, b) {
    alert( a + b );
}
  
  f.defer(1000)(1, 2); // shows 3 after 1 second
//   Please note that the arguments should be passed to the original function.


Function.prototype.defer = function(ms) {
    let f = this;
    return function(...args) {
      setTimeout(() => f.apply(this, args), ms);
    }
  };
  
  // check it
  function f(a, b) {
    alert( a + b );
  }
  
  f.defer(1000)(1, 2); // shows 3 after 1 sec


//   The difference between calls
// importance: 5
// Let’s create a new rabbit object:

function Rabbit(name) {
  this.name = name;
}
Rabbit.prototype.sayHi = function() {
  alert(this.name);
};

let rabbit4 = new Rabbit("Rabbit");

// These calls do the same thing or not?

rabbit4.sayHi();
Rabbit.prototype.sayHi();
Object.getPrototypeOf(rabbit4).sayHi();
rabbit4.__proto__.sayHi();


// The first call has this == rabbit, the other ones have this equal to Rabbit.prototype, because it’s actually the object before the dot.

// So only the first call shows Rabbit, other ones show undefined:

function Rabbit(name) {
  this.name = name;
}
Rabbit.prototype.sayHi = function() {
  alert( this.name );
}

let rabbit5 = new Rabbit("Rabbit");

rabbit5.sayHi();                        // Rabbit
Rabbit.prototype.sayHi();              // undefined
Object.getPrototypeOf(rabbit5).sayHi(); // undefined
rabbit5.__proto__.sayHi();              // undefined




// Exercise 1:
// Define a filter function on the String object. The function accepts an array of strings that
// specifies a list of banned words. The function returns the string after removing all the
// banned words.
// Example:
// console.log("This house is not nice!".filter('not'));
// Output: "This house is nice!"





String.prototype.filter = function(args) {
    let result = this;
    args.forEach(e => {
        result = result.replace(e,"")
    });
    return result;
}
let str = "hello world miu";
console.log(str);   
console.log(str.filter(["world","miu"]));


// Exercise 2:
// Write a BubbleSort algorithm on the Array object. Bubble sort is a simple sorting algorithm
// that works by repeatedly stepping through the list to be sorted,
// Example:[6,4,0, 3,-2,1].bubbleSort();
// Output : [-2, 0, 1, 3, 4, 6]

Array.prototype.bubbleSort = function() {
    let arr = this;
    let len = arr.length;
    for (let i = 0; i < len; i++) {
        for (let j = 0; j < len; j++) {
            if (arr[j] > arr[i]) {
                let temp = arr[j];
                arr[j] = arr[i];
                arr[i] = temp;
            }
        }

    }
    return arr;
}
console.log([6,4,0, 3,-2,1]);
console.log([6,4,0, 3,-2,1].bubbleSort());


// Exercise 3:
// The last exercise for today comes from: https://www.learn-js.org/en/Inheritance
// Create an object called Teacher derived from the Person class, and implement a method called teach
// which receives a string called subject, and returns:
// [teacher's name] is now teaching [subject]
// Here is code for Person and an example of a Student function constructor. 
var Person = function() {};

Person.prototype.initialize = function(name, age) {
    this.name = name;
    this.age = age;
};

Person.prototype.describe = function() {
 return this.name + ", " + this.age + " years old.";
};

var Student = function() {};
Student.prototype = new Person();

var Teacher = function(){};
Teacher.prototype = new Person();

Teacher.prototype.teach = function(subject){
    return  this.name + " is now teaching " + subject;
};


